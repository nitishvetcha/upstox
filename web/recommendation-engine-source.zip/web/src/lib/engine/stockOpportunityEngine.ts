// Phase 20 — Stock Opportunity Engine v20.0 → 20.1
// Multi-factor intraday and swing scanner for NIFTY 50.
// Uses a single batch API call for quotes, then scores each stock on
// multiple factors including relative strength vs NIFTY.
// ponytail: per-stock VWAP/EMA/RSI not computed (would require 50 candle-history calls);
//           add targeted technicals fetch for top-N candidates when latency budget allows.
import { get } from "../services/upstoxMarket.ts";
import { getAccessToken } from "../services/upstoxAuth.ts";
import { providerMode } from "../services/market.ts";
import { NIFTY_50 } from "../services/breadthConstituents.generated.ts";
import type { StockInstrument, StockMarketData } from "../services/stockService.ts";
import { normalizeStockQuote } from "../services/stockService.ts";
import { marketStatus } from "../time.ts";
import { gradeOpportunity, type OpportunityGrade } from "./opportunityEngine.ts";
import { evaluatePositional, withTodayBar, POSITIONAL_RETIRED_NOTE } from "./positionalTrend.ts";
import { loadHistory } from "../marketHistory.ts";
import { upstoxHistoryFetcher } from "../services/upstoxMarket.ts";
import { cached } from "../services/cache.ts";
import { istToday, latestTradingSessionDate } from "../time.ts";
import type { Candle } from "../types.ts";
import { UpstoxError } from "../services/errors.ts";

export const STOCK_OPPORTUNITY_VERSION = "20.1";

// ── Setup types ───────────────────────────────────────────────────────────────
export type IntradaySetup =
  | "BREAKOUT"          // price above PDH
  | "BREAKDOWN"         // price below PDL
  | "HOD_CONTINUATION"  // price consolidating near HOD with strong change
  | "LOD_CONTINUATION"  // price consolidating near LOD with strong sell
  | "MOMENTUM_LONG"     // strong positive change, upper range, volume
  | "MOMENTUM_SHORT"    // strong negative change, lower range, volume
  | "WEAK_LONG"         // positive but poor quality
  | "WEAK_SHORT"        // negative but poor quality

export type SwingSetup =
  | "BREAKOUT"          // daily close above multi-day resistance
  | "BREAKDOWN"         // daily close below multi-day support
  | "TREND_CONTINUATION_LONG"  // stock consistently above key EMAs, pullback to support
  | "TREND_CONTINUATION_SHORT"
  | "MOMENTUM"          // large 1-day move with strong closing position
  | "WEAK"              // insufficient evidence

export interface StockOpportunity {
  rank: number;
  symbol: string;
  name: string;
  instrumentKey: string;
  // Quote data
  ltp: number;
  open: number | null;
  high: number | null;
  low: number | null;
  previousClose: number | null;
  change: number | null;
  changePercent: number | null;
  volume: number | null;
  freshness: string;
  fetchedAt?: string | null;
  exchangeTimestamp?: string | null;
  dataAgeSeconds?: number | null;
  sessionDate?: string | null;
  source?: string | null;
  // Setup
  opportunityScore: number;
  setup: IntradaySetup | SwingSetup;
  direction: "BULLISH" | "BEARISH";
  // Trade plan
  entry: number;
  entryLow: number;
  entryHigh: number;
  stop: number;
  target1: number;
  target2: number;
  rr: number;
  // Analysis
  relativeStrength: number | null; // vs NIFTY in % points (intraday: today's change; positional: 20-session return)
  confidence?: number;
  rangePosition: number | null;    // 0=LOD, 1=HOD
  reasons: string[];
  invalidation: string;
  grade: OpportunityGrade;
  gradeReasons?: string[];
}

export interface StockOpportunityResult {
  timestamp: string;
  engineVersion: string;
  kind: "intraday" | "swing";
  source: "UPSTOX" | "MOCK" | "MIXED" | "UNAVAILABLE";
  freshness: string;
  universe: string;
  stocksScanned: number;
  stocksAvailable: number;
  stocksRejected: number;
  niftyChange: number | null;    // context for relative strength
  topOpportunities: StockOpportunity[];
  noOpportunityReason: string | null;
  diagnostics?: StockCollectionDiagnostics;
}

export type StockProviderFailureCategory =
  | "AUTHENTICATION"
  | "AUTHORIZATION"
  | "RATE_LIMIT"
  | "TIMEOUT"
  | "NETWORK"
  | "MALFORMED_RESPONSE"
  | "PARTIAL_COVERAGE"
  | "PROVIDER_API_ERROR";

export interface StockCollectionDiagnostics {
  requested: number;
  covered: number;
  category: StockProviderFailureCategory | null;
  providerCode: string | null;
  httpStatus: number | null;
}

export function stockProviderFailureCategory(error: unknown): StockProviderFailureCategory {
  if (!(error instanceof UpstoxError)) return "NETWORK";
  switch (error.reason) {
    case "UPSTOX_AUTH_EXPIRED": return "AUTHENTICATION";
    case "UPSTOX_FORBIDDEN": return "AUTHORIZATION";
    case "UPSTOX_RATE_LIMITED": return "RATE_LIMIT";
    case "UPSTOX_TIMEOUT": return "TIMEOUT";
    case "UPSTOX_NETWORK": return "NETWORK";
    case "UPSTOX_BAD_RESPONSE": return "MALFORMED_RESPONSE";
    default: return "PROVIDER_API_ERROR";
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────
const r2 = (n: number) => Math.round(n * 100) / 100;
const MS_TO_STATUS = { OPEN: "OPEN", CLOSED: "CLOSED", "PRE-OPEN": "PRE_OPEN" } as const;

// Batch quote: one API call with comma-separated instrument keys
async function batchQuotes(instruments: StockInstrument[], now: Date): Promise<StockMarketData[]> {
  const token = await getAccessToken();
  const unavailable = (inst: StockInstrument, reason: string): StockMarketData => ({
    symbol: inst.symbol, exchange: "NSE" as const, instrumentKey: inst.instrumentKey,
    timestamp: now.toISOString(), ltp: null,
    marketStatus: MS_TO_STATUS[marketStatus(now)] ?? "UNKNOWN",
    freshness: "UNAVAILABLE" as const, source: null, unavailableReason: reason,
  });
  if (!token) return instruments.map((i) => unavailable(i, "AUTHENTICATION: UPSTOX_NOT_CONNECTED"));
  const keys = instruments.map((i) => i.instrumentKey).join(",");
  try {
    const raw = await get(token, "/v2/market-quote/quotes", { instrument_key: keys }, { index: "nifty" }) as Record<string, Record<string, unknown>>;
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return instruments.map((inst) => unavailable(inst, "MALFORMED_RESPONSE: quote data is not an object"));
    }
    const byToken = new Map<string, Record<string, unknown>>();
    for (const entry of Object.values(raw)) {
      const instrumentToken = entry?.instrument_token;
      if (typeof instrumentToken === "string" && !byToken.has(instrumentToken)) byToken.set(instrumentToken, entry);
    }
    return instruments.map((inst) => {
      const entry = byToken.get(inst.instrumentKey);
      if (!entry) return unavailable(inst, "PARTIAL_COVERAGE: provider omitted requested instrument");
      if (typeof entry.last_price !== "number" || !Number.isFinite(entry.last_price) || entry.last_price <= 0) {
        return unavailable(inst, "MALFORMED_RESPONSE: quote missing positive last_price");
      }
      return normalizeStockQuote({ [inst.instrumentKey]: entry }, inst, now, "UPSTOX"); // this batch is the Upstox request
    });
  } catch (e) {
    const category = stockProviderFailureCategory(e);
    const providerCode = e instanceof UpstoxError ? e.reason : "UPSTOX_NETWORK";
    const status = e instanceof UpstoxError && e.status !== null ? ` HTTP_${e.status}` : "";
    return instruments.map((i) => unavailable(i, `${category}: ${providerCode}${status}`));
  }
}

function stockDiagnostics(quotes: StockMarketData[], requested: number): StockCollectionDiagnostics {
  const covered = quotes.filter((q) => q.ltp !== null).length;
  const reasons = quotes.map((q) => q.unavailableReason ?? "");
  const category = covered > 0 && covered < requested ? "PARTIAL_COVERAGE"
    : (["AUTHENTICATION", "AUTHORIZATION", "RATE_LIMIT", "TIMEOUT", "NETWORK", "MALFORMED_RESPONSE", "PARTIAL_COVERAGE", "PROVIDER_API_ERROR"] as const)
      .find((candidate) => reasons.some((reason) => reason.startsWith(`${candidate}:`))) ?? null;
  const coded = reasons.find((reason) => reason.includes("UPSTOX_")) ?? "";
  const providerCode = coded.match(/UPSTOX_[A-Z_]+/)?.[0] ?? null;
  const httpStatus = Number(coded.match(/HTTP_(\d+)/)?.[1] ?? NaN);
  return { requested, covered, category, providerCode, httpStatus: Number.isFinite(httpStatus) ? httpStatus : null };
}

// Range position: 0 = at LOD, 1 = at HOD
function rangePosition(ltp: number, high: number | undefined, low: number | undefined): number | null {
  if (high === undefined || low === undefined || high <= low) return null;
  return (ltp - low) / (high - low);
}

// Share of independent checks agreeing with the trade side (70%) + quote quality (30%).
// Only describes evidence; eligibility (live data, R:R) is enforced separately by gradeOpportunity/filters.
export function intradayConfidence(q: StockMarketData, side: 1 | -1, rs: number | null, pos: number): number {
  const ltp = q.ltp!;
  const checks: (boolean | null)[] = [
    q.previousClose ? side * (ltp - q.previousClose) > 0 : null,
    q.open !== undefined ? side * (ltp - q.open) > 0 : null,
    q.high !== undefined && q.low !== undefined && q.high > q.low ? (side > 0 ? pos > 0.6 : pos < 0.4) : null,
    rs !== null ? side * rs > 0.3 : null,
    q.changePercent !== undefined ? Math.abs(q.changePercent) >= 1 : null,
  ];
  const known = checks.filter((c): c is boolean => c !== null);
  if (!known.length) return 0;
  const agree = known.filter(Boolean).length / known.length;
  const quality = (q.freshness === "LIVE" ? 0.6 : 0) + (q.volume ? 0.2 : 0) + (known.length === checks.length ? 0.2 : 0);
  return Math.round(agree * 70 + quality * 30);
}

// Detect intraday setup from available OHLC + change data
function detectIntradaySetup(q: StockMarketData, niftyChgPct: number | null): {
  setup: IntradaySetup; direction: "BULLISH" | "BEARISH"; score: number; reasons: string[]; confidence: number;
} {
  const chg = q.changePercent ?? 0;
  const pos = rangePosition(q.ltp!, q.high, q.low) ?? 0.5;
  const volOk = q.volume !== undefined && q.volume > 0;
  const absPct = Math.abs(chg);

  // Outperformance in percentage points vs NIFTY. A ratio flips sign on red days.
  const rs = niftyChgPct !== null ? chg - niftyChgPct : null;

  const reasons: string[] = [];
  let score = 0;

  if (chg >= 0) {
    // Bullish direction
    if (q.previousClose && q.ltp! > q.previousClose * 1.005) {
      score += 15; reasons.push(`Trading above yesterday's close`);
    }
    if (q.open !== undefined && q.ltp! > q.open) { score += 10; reasons.push(`Above today's open (buyers in control)`); }
    if (pos > 0.80) { score += 20; reasons.push(`Price near HOD (${(pos * 100).toFixed(0)}% of range)`); }
    else if (pos > 0.60) { score += 10; }
    if (absPct >= 2.5) { score += 20; reasons.push(`Strong move +${absPct.toFixed(1)}%`); }
    else if (absPct >= 1.0) { score += 10; reasons.push(`Positive +${absPct.toFixed(1)}%`); }
    if (rs !== null && rs > 1) { score += 15; reasons.push(`Beating NIFTY by ${rs.toFixed(1)}%`); }
    else if (rs !== null && rs > 0.3) { score += 5; reasons.push(`Slightly stronger than NIFTY (+${rs.toFixed(1)}%)`); }
    if (volOk) reasons.push(`Volume: ${(q.volume! / 1000).toFixed(0)}K`);

    const setup: IntradaySetup =
      (q.previousClose !== null && q.ltp! > (q.previousClose || 0) * 1.005) ? "BREAKOUT"
      : pos > 0.8 && absPct >= 2 ? "HOD_CONTINUATION"
      : absPct >= 1 ? "MOMENTUM_LONG" : "WEAK_LONG";

    return { setup, direction: "BULLISH", score: Math.min(100, score), reasons, confidence: intradayConfidence(q, 1, rs, pos) };
  } else {
    // Bearish direction
    const absPct = Math.abs(chg);
    if (q.previousClose && q.ltp! < q.previousClose * 0.995) {
      score += 15; reasons.push(`Trading below yesterday's close`);
    }
    if (q.open !== undefined && q.ltp! < q.open) { score += 10; reasons.push(`Below today's open (sellers in control)`); }
    if (pos < 0.20) { score += 20; reasons.push(`Price near LOD (${(pos * 100).toFixed(0)}% of range)`); }
    else if (pos < 0.40) { score += 10; }
    if (absPct >= 2.5) { score += 20; reasons.push(`Strong drop −${absPct.toFixed(1)}%`); }
    else if (absPct >= 1.0) { score += 10; reasons.push(`Negative −${absPct.toFixed(1)}%`); }
    if (rs !== null && rs < -1) { score += 15; reasons.push(`Weaker than NIFTY by ${Math.abs(rs).toFixed(1)}%`); }
    if (volOk) reasons.push(`Volume: ${(q.volume! / 1000).toFixed(0)}K`);

    const setup: IntradaySetup =
      (q.previousClose !== null && q.ltp! < (q.previousClose || 0) * 0.995) ? "BREAKDOWN"
      : pos < 0.2 && absPct >= 2 ? "LOD_CONTINUATION"
      : absPct >= 1 ? "MOMENTUM_SHORT" : "WEAK_SHORT";

    return { setup, direction: "BEARISH", score: Math.min(100, score), reasons, confidence: intradayConfidence(q, -1, rs, pos) };
  }
}

// Build trade plan using structural levels (HOD/LOD as stops) and ATR extensions as targets.
// Target is market-derived — NOT forced to achieve a desired R:R.
// The ATR multiplier increases for strong-momentum setups (RS > 1.5×, move > 2.5%).
// This reflects that high-momentum continuation moves typically extend further.
// R:R is CALCULATED after targets are set; poor R:R setups are rejected by the scanner.
function buildTradePlan(
  q: StockMarketData, direction: "BULLISH" | "BEARISH", relStr: number | null,
) {
  const ltp = q.ltp!;
  const high = q.high ?? ltp;
  const low = q.low ?? ltp;
  const dayRange = high - low;
  const atrProxy = Math.max(dayRange, ltp * 0.008); // 0.8% floor

  // Strong-momentum extension: applies when stock has clear relative outperformance/underperformance
  const absPct = Math.abs(q.changePercent ?? 0);
  const strongMomentum = absPct >= 2.5 && relStr !== null && Math.abs(relStr) >= 1.5 && Math.sign(relStr) === Math.sign(q.changePercent ?? 0);
  // ponytail: 1.2× gives R:R ≈ 1.04 at LOD/HOD; 1.75× gives R:R ≈ 1.52
  const targetMult = strongMomentum ? 1.75 : 1.2;

  if (direction === "BULLISH") {
    const stop = r2(low - atrProxy * 0.15);
    const risk = Math.max(ltp - stop, 0.01);
    const t1 = r2(ltp + atrProxy * targetMult);
    const t2 = r2(ltp + atrProxy * targetMult * 1.8);
    return {
      entry: ltp, entryLow: r2(ltp), entryHigh: r2(ltp * 1.003),
      stop, target1: t1, target2: t2, rr: r2((t1 - ltp) / risk),
    };
  } else {
    const stop = r2(high + atrProxy * 0.15);
    const risk = Math.max(stop - ltp, 0.01);
    const t1 = r2(ltp - atrProxy * targetMult);
    const t2 = r2(ltp - atrProxy * targetMult * 1.8);
    return {
      entry: ltp, entryLow: r2(ltp * 0.997), entryHigh: r2(ltp),
      stop, target1: t1, target2: t2, rr: r2((ltp - t1) / risk),
    };
  }
}

// 6 months of daily candles per instrument, fetched once per IST day.
// Sequential on purpose: the history fetcher spaces calls ~130 ms apart and that spacing is not concurrency-safe.
const NIFTY_KEY = "NSE_INDEX|Nifty 50";
async function dailyCandles(keys: string[], token: string, now: Date): Promise<Map<string, Candle[]>> {
  return cached(`positional-daily:${istToday(now)}:${keys.length}`, 6 * 3600_000, async () => {
    const out = new Map<string, Candle[]>();
    const fetcher = upstoxHistoryFetcher(token);
    for (const k of keys) {
      try { out.set(k, (await loadHistory(k, "1d", "6M", fetcher, { now })).candles); } catch { /* missing → rejected with reason */ }
    }
    return out;
  });
}

// The intraday candidate rule, shared by the live scanner and the historical replay (one implementation).
export function scoreIntradayQuote(q: StockMarketData, niftyChgPct: number | null) {
  const scored = detectIntradaySetup(q, niftyChgPct);
  if (scored.score < 30) return null;
  const chg = q.changePercent ?? 0;
  const rs = niftyChgPct !== null ? r2(chg - niftyChgPct) : null;
  const plan = buildTradePlan(q, scored.direction, rs);
  if (plan.rr < 1.0) return null;
  return { scored, rs, plan };
}

// NIFTY change proxy used by the scanner: mean constituent change %, only when more than 10 have data.
export function niftyProxyChange(changes: number[]): number | null {
  return changes.length > 10 ? changes.reduce((a, b) => a + b, 0) / changes.length : null;
}

// ── Main scanner ──────────────────────────────────────────────────────────────

// Data sources are injectable so tests use deterministic fixtures instead of the live Upstox API.
export interface ScanDeps {
  quotes?: (instruments: StockInstrument[], now: Date) => Promise<StockMarketData[]>;
  daily?: (keys: string[], now: Date) => Promise<Map<string, Candle[]>>;
}

// Outside Upstox mode the scan returns UNAVAILABLE before any token is read or any request is made.
// No stock opportunity is fabricated as a substitute.
export function unavailableStockScan(kind: "intraday" | "swing", now: Date): StockOpportunityResult {
  return {
    timestamp: now.toISOString(), engineVersion: STOCK_OPPORTUNITY_VERSION, kind,
    source: "UNAVAILABLE", freshness: "UNAVAILABLE", universe: "NIFTY_50",
    stocksScanned: NIFTY_50.length, stocksAvailable: 0, stocksRejected: 0,
    niftyChange: null, topOpportunities: [],
    noOpportunityReason: "Stock data is not available: the application is not in Upstox mode (MARKET_DATA_PROVIDER is not upstox). No stock quotes were requested.",
  };
}

export async function scanStocks(kind: "intraday" | "swing", now = new Date(), deps: ScanDeps = {}): Promise<StockOpportunityResult> {
  // First check, before any token access (getAccessToken / token file / analytics token) and before any HTTP request.
  if (providerMode() !== "upstox") return unavailableStockScan(kind, now);
  const instruments: StockInstrument[] = NIFTY_50.map((c) => ({
    symbol: c.symbol, name: c.name, exchange: "NSE" as const,
    instrumentKey: c.instrumentKey, kind: "EQUITY" as const,
  }));

  // Also fetch NIFTY index quote for relative strength calculation.
  // We include it in the batch — NSE_INDEX|13 is NIFTY 50.
  const quotes = await (deps.quotes ?? batchQuotes)(instruments, now);
  const diagnostics = stockDiagnostics(quotes, instruments.length);
  const available = quotes.filter((q) => q.ltp !== null && q.freshness !== "UNAVAILABLE");
  // Derived from the quotes' own provider, never a constant. Mixed providers are reported as MIXED.
  const providers = new Set(available.map((q) => q.source ?? "NONE"));
  const source: "UPSTOX" | "MOCK" | "MIXED" | "UNAVAILABLE" = available.length === 0 ? "UNAVAILABLE"
    : providers.size === 1 && providers.has("UPSTOX") ? "UPSTOX"
    : providers.size === 1 && providers.has("MOCK") ? "MOCK"
    : "MIXED";
  const freshness = available.length === 0 ? "UNAVAILABLE"
    : available.every((q) => q.freshness === "LIVE") ? "LIVE" : "MIXED";

  // Estimate NIFTY change from constituent moves (proxy when index not in batch)
  const niftyChanges = available
    .filter((q) => q.changePercent !== undefined)
    .map((q) => q.changePercent!);
  const niftyChgPct = niftyProxyChange(niftyChanges);

  const opportunities: StockOpportunity[] = [];
  let rejected = 0;

  if (kind === "swing") {
    const token = await getAccessToken();
    const keys = [NIFTY_KEY, ...available.map((q) => q.instrumentKey!)];
    const daily = deps.daily ? await deps.daily(keys, now)
      : token && available.length ? await dailyCandles(keys, token, now) : new Map<string, Candle[]>();
    const today = latestTradingSessionDate(now); // quote OHLC belongs to this session, even on weekends
    const bench = daily.get(NIFTY_KEY) ?? null;
    const whyNot = new Map<string, number>();
    for (const q of available) {
      const inst = instruments.find((i) => i.symbol === q.symbol);
      const hist = daily.get(q.instrumentKey!);
      if (!inst || !hist) { rejected++; continue; }
      // B5-adj: A live quote from current session, or the latest completed session EOD quote outside market hours.
      const quoteDay = q.sessionDate
        ?? (q.exchangeTimestamp ? istToday(new Date(q.exchangeTimestamp)) : null)
        ?? (q.timestamp ? istToday(new Date(q.timestamp)) : null);
      const usable = (q.freshness === "LIVE" || q.freshness === "END_OF_DAY") && quoteDay === today;
      if (!usable) {
        rejected++;
        const why = `Quote not live/EOD for this session (${q.freshness})`;
        whyNot.set(why, (whyNot.get(why) ?? 0) + 1);
        continue;
      }
      const sig = evaluatePositional(withTodayBar(hist, q, today), bench, now, true);
      if (!sig.ok) { rejected++; whyNot.set(sig.reason.split(" (")[0], (whyNot.get(sig.reason.split(" (")[0]) ?? 0) + 1); continue; }
      opportunities.push({
        rank: 0, symbol: q.symbol, name: inst.name, instrumentKey: q.instrumentKey ?? "",
        ltp: q.ltp!, open: q.open ?? null, high: q.high ?? null, low: q.low ?? null,
        previousClose: q.previousClose ?? null, change: q.change ?? null, changePercent: q.changePercent ?? null,
        volume: q.volume ?? null, freshness: q.freshness,
        opportunityScore: sig.score, setup: sig.setup, direction: "BULLISH",
        entry: sig.entry, entryLow: r2(sig.entry * 0.99), entryHigh: sig.entry, stop: sig.stop,
        target1: sig.target1, target2: sig.target2, rr: sig.rr,
        relativeStrength: sig.rs20, rangePosition: rangePosition(q.ltp!, q.high, q.low),
        invalidation: sig.invalidation,
        grade: "REJECT", // retired strategy: observation only
        reasons: [`⚠ ${POSITIONAL_RETIRED_NOTE}`, ...sig.reasons],
        confidence: sig.confidence,
      });
    }
    opportunities.sort((a, b) => b.opportunityScore - a.opportunityScore);
    const top = opportunities.slice(0, 3).map((o, i) => ({ ...o, rank: i + 1 })); // same top-3 contract as intraday (SO-05)
    const topReasons = [...whyNot].sort((a, b) => b[1] - a[1]).slice(0, 3).map(([r, n]) => `${n}× ${r}`).join("; ");
    return {
      timestamp: now.toISOString(), engineVersion: STOCK_OPPORTUNITY_VERSION, kind, source, freshness,
      universe: "NIFTY_50", stocksScanned: instruments.length, stocksAvailable: available.length, stocksRejected: rejected,
      niftyChange: niftyChgPct !== null ? r2(niftyChgPct) : null, topOpportunities: top,
      noOpportunityReason: top.length ? null
        : source === "UNAVAILABLE" ? "Upstox not connected — no stock data available"
        : !bench ? "Daily candle history could not be loaded"
        : `No stock in a clean uptrend right now. Most common: ${topReasons}`,
      diagnostics,
    };
  }

  for (const q of available) {
    if (q.ltp === null) { rejected++; continue; }

    // Intraday recommendations use current-session LIVE quotes during market hours,
    // or latest completed trading session END_OF_DAY quotes outside market hours.
    const quoteSessionDate = q.sessionDate
      ?? (q.exchangeTimestamp ? istToday(new Date(q.exchangeTimestamp)) : null)
      ?? (q.timestamp ? istToday(new Date(q.timestamp)) : null);
    const isSessionUsable = (q.freshness === "LIVE" && quoteSessionDate === istToday(now))
      || (q.freshness === "END_OF_DAY" && quoteSessionDate === latestTradingSessionDate(now));
    if (!isSessionUsable) {
      rejected++;
      continue;
    }

    const inst = instruments.find((i) => i.symbol === q.symbol);
    if (!inst) { rejected++; continue; }

    const res = scoreIntradayQuote(q, niftyChgPct);
    if (!res) { rejected++; continue; }
    const { scored, rs, plan } = res;

    const invalidation = scored.direction === "BULLISH"
      ? `Price breaks below ${r2(q.low ?? (q.ltp! * 0.995))}`
      : `Price breaks above ${r2(q.high ?? (q.ltp! * 1.005))}`;

    // liveSources=3 only when the quote is genuinely LIVE; END_OF_DAY/STALE → 0 → forces REJECT grade
    const liveSourcesCount = q.freshness === "LIVE" ? 3 : 0;
    const rawGrade = gradeOpportunity(scored.score, plan.rr, scored.confidence, liveSourcesCount);
    const gradeReasons: string[] = [];
    if (q.freshness !== "LIVE") {
      gradeReasons.push(`Quote ${q.freshness}, not live`);
    }
    if (scored.score < 40) {
      gradeReasons.push(`Opportunity score ${scored.score}/100 below minimum threshold (40)`);
    }
    if (plan.rr < 1.0) {
      gradeReasons.push(`Risk/reward ratio ${plan.rr}x below minimum threshold (1.0x)`);
    }
    if (rawGrade === "REJECT" && gradeReasons.length === 0) {
      gradeReasons.push("Did not meet quality thresholds for tradable grade");
    }

    opportunities.push({
      rank: 0,
      symbol: q.symbol,
      name: inst.name,
      instrumentKey: q.instrumentKey ?? "",
      ltp: q.ltp!,
      open: q.open ?? null,
      high: q.high ?? null,
      low: q.low ?? null,
      previousClose: q.previousClose ?? null,
      change: q.change ?? null,
      changePercent: q.changePercent ?? null,
      volume: q.volume ?? null,
      freshness: q.freshness,
      fetchedAt: q.fetchedAt ?? now.toISOString(),
      exchangeTimestamp: q.exchangeTimestamp ?? null,
      dataAgeSeconds: q.dataAgeSeconds ?? null,
      sessionDate: quoteSessionDate,
      source: q.source,
      opportunityScore: scored.score,
      setup: scored.setup,
      direction: scored.direction,
      ...plan,
      relativeStrength: rs,
      rangePosition: rangePosition(q.ltp!, q.high, q.low),
      reasons: scored.reasons,
      invalidation,
      grade: rawGrade,
      gradeReasons,
      confidence: scored.confidence,
    });
  }

  opportunities.sort((a, b) => b.opportunityScore - a.opportunityScore);
  const top3 = opportunities.slice(0, 3).map((o, i) => ({ ...o, rank: i + 1 }));

  return {
    timestamp: now.toISOString(),
    engineVersion: STOCK_OPPORTUNITY_VERSION,
    kind,
    source,
    freshness,
    universe: "NIFTY_50",
    stocksScanned: instruments.length,
    stocksAvailable: available.length,
    stocksRejected: rejected,
    niftyChange: niftyChgPct !== null ? r2(niftyChgPct) : null,
    topOpportunities: top3,
    noOpportunityReason: top3.length === 0
      ? source === "UNAVAILABLE"
        ? "Upstox not connected — no live stock data available"
        : `No stock passed quality filters (${rejected} rejected from ${available.length} scanned)`
      : null,
    diagnostics,
  };
}
